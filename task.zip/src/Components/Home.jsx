import React from 'react'
import Header from './Header';
import Banner from './Banner';
import Featured from './Featured';

function Home() {
  return (
    <>
      <Header/>
      <Banner/>
      <Featured/>
    </>
  )
}

export default Home;