import React from 'react'

const Featured = () => {
    return (
        <>
            <div className="row">
                <div className="col-md-7">
                    <div className="row">
                        <div className="col-md-6">
                            <img
                                className="d-block "
                                src={require("../assets/images/featured.jpg")} alt="" style={{ 'margin': '150px 0 0 100px', 'width':'60%', 'height':'60%' }} />
                            <div className='bg-warning' style={{ 'border-radius': '50%', 'width': '100px', 'position': 'relative', 'left': '60px', 'bottom': '50px' }}>
                                <img
                                    src={require("../assets/images/featured-icon.png")}
                                    alt="" height={'100px'} style={{ 'padding': '20px', }}
                                />
                            </div>
                        </div>

                        <div className="col-md-6" style={{ 'textAlign': 'left', 'margin-top': '150px' }}>
                            <p className='text-warning'>| FEATURED</p>
                            <h1>
                                Best Appartment & Sea View
                            </h1>
                            <div style={{ 'background': '#F5F5F5' }}>
                                <p className='text-warning'>Best useful links?</p>
                                <hr />
                                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut quaerat rem dolor totam unde error deserunt quisquam iusto culpa impedit aspernatur, numquam nam. Iste quam quasi consectetur alias velit neque!</p>

                                <p>How does this work?</p>
                                <hr />
                                <p>Why is Villa Agency the best?</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-5">
                    <ul class="list-group" style={{'margin-top':'150px', 'padding':'0 60px 0'}}>
                        <li class="list-group-item">
                            <div className="row">
                                <div className="col-3"><img src={require("../assets/images/info-icon-01.png")} alt="" /></div>
                                <div className="col-7" style={{'textAlign':'left'}}>
                                    <h4>250 m2</h4>
                                    <p>Total Flat Space</p>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                        <div className="row">
                                <div className="col-3"><img src={require("../assets/images/info-icon-02.png")} alt="" /></div>
                                <div className="col-7" style={{'textAlign':'left'}}>
                                    <h4>Contract</h4>
                                    <p>Contract Reality</p>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                        <div className="row">
                                <div className="col-3"><img src={require("../assets/images/info-icon-03.png")} alt="" /></div>
                                <div className="col-7" style={{'textAlign':'left'}}>
                                    <h4>Payment</h4>
                                    <p>Payment</p>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                        <div className="row">
                                <div className="col-3"><img src={require("../assets/images/info-icon-04.png")} alt="" /></div>
                                <div className="col-7" style={{'textAlign':'left'}}>
                                    <h4>Safety</h4>
                                    <p>24/7 Under</p>
                                </div>
                            </div>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </>)
}

export default Featured;